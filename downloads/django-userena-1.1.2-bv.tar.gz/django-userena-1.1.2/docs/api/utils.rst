.. _api-utils:

Utils
=====

.. automodule:: userena.utils

get_gravatar
------------

.. autofunction:: userena.utils.get_gravatar

signin_redirect
---------------

.. autofunction:: userena.utils.signin_redirect

generate_sha1
-------------

.. autofunction:: userena.utils.generate_sha1

get_profile_model
-----------------

.. autofunction:: userena.utils.get_profile_model
 
