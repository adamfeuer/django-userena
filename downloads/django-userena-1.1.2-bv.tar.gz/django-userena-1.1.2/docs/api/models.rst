.. _api-models:

Models
======

.. automodule:: userena.models

Return to :ref:`api`.

upload_to_mugshot
-----------------

.. autofunction:: userena.models.upload_to_mugshot

UserenaSignup
-------------

.. autoclass:: userena.models.UserenaSignup
   :members:

UserenaBaseProfile
------------------

.. autoclass:: userena.models.UserenaBaseProfile
   :members:

UserenaLanguageBaseProfile
--------------------------

.. autoclass:: userena.models.UserenaLanguageBaseProfile
   :members:

