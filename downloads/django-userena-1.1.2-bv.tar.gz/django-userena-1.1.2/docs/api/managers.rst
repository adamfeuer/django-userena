.. _api-managers:

Managers
========

.. automodule:: userena.managers

Return to :ref:`api`

UserenaManager
--------------

.. autoclass:: userena.managers.UserenaManager
   :members:

UserenaBaseProfileManager
-------------------------

.. autoclass:: userena.managers.UserenaBaseProfileManager
   :members:
