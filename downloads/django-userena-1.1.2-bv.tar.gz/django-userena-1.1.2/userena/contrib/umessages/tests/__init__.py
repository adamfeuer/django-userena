from userena.contrib.umessages.tests.fields import *
from userena.contrib.umessages.tests.forms import *
from userena.contrib.umessages.tests.managers import *
from userena.contrib.umessages.tests.models import *
from userena.contrib.umessages.tests.views import *
